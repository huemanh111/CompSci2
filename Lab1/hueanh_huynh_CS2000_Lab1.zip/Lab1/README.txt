Hue Anh Huynh
Computer Science II 
Lab 1

Instructions
1. Unzip the files
2. Log into your erdos account
3. Navigate to the directory where you saved the files with the cd command
4. Type in:
		g++ accountTest.cpp account.cpp
5. It should compile with no errors then type:
		./a.out