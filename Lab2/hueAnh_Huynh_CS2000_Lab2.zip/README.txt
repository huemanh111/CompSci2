Hue Anh Huynh
10/3/17

1. Download zip
2. Unzip
3. Run lab2.cpp
4. Follow instructions throughout program
