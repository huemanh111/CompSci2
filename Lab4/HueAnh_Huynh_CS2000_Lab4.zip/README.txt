1. Downlaod file
2. Unzip
3. Open up your erdos account
4. Naviagte to where you stored the entirety of my lab 4 files
5. To test problem 1 of the lab enter:
	g++ complex.cpp complexTest.cpp
	./a.out
6. To test problem 2 of the lab enter:
	g++ sort.cpp
	./a.out
7. To test problem 3 of the lab enter:
	g++ account.cpp checkingAccount.cpp savingsAccount.cpp accountTest.cpp
	./a.out