Hue Anh Huynh
10/10/17
CS2 Lab3


Steps
1. Download zip
2. Unzip
3. Log into your erdos account
4. Compile all the .cpp files in the folder (g++ account.cpp accountManager.cpp mainTest.cpp)
5. ./a.out to output results
